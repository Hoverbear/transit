fn main() {
    do_nested();

    do_some_opt();

    do_none_opt();

    do_tuple();

    do_ok_err();
}

fn do_nested() {
    let x = 0;
    let mut y = 0;
    println!("{} {}", x, y);
    {
        let x = 10;
        y = 1;
        println!("nested {} {}", x, y);
    }
}

fn do_some_opt() {
    let some : Option<u64> = Some(0);
    if let Some(x) = some {
        println!("if let Some({})", x);
    }
    while let Some(y) = some {
        println!("while let Some({})", y);
        break;
    }
}

fn do_none_opt() {
    let none : Option<u64> = None;
    if let Some(x) = none {
        println!("This if let Some({}) will never execute.", x);
    }
}

fn do_tuple() {
    let (x, y) = (42, 44);
    println!("({}, {})", x, y);
}

fn do_ok_err() {
    let result_ok : Result<u64, &'static str> = Ok(0);
    let result_err : Result<u64, &'static str> = Err("This is an error.");
    if let (Ok(a), Err(b)) = (result_ok, result_err) {
        println!("(Ok({}), Err({}))", a, b);
    }
}
